<?php
// includes/db.php
$host = 'localhost';
$dbname = 'penjualan';  // Nama database Anda
$username = 'root';      // Username MySQL Anda
$password = '';          // Password MySQL Anda

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    $conn = null;
}
