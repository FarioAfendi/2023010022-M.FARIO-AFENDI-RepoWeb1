<footer class="bg-light text-center py-3 mt-5">
    <p>&copy; 2025 Sistem Pemasaran Tanaman. All rights reserved.</p>
</footer>