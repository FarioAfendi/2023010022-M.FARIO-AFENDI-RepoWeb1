<?php
include 'includes/header.php';
include 'includes/db.php';

if ($conn) {
    $sql = "SELECT * FROM products";
    $stmt = $conn->query($sql);
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    echo "<p>Gagal terhubung ke database.</p>";
}
?>

<main>
    <h2>Daftar Produk</h2>
    <a href="add-product.php">Tambah Produk</a>
    <table border="1">
        <tr>
            <th>Nama Produk</th>
            <th>Harga</th>
            <th>Aksi</th>
        </tr>
        <?php foreach ($products as $product): ?>
            <tr>
                <td><?= htmlspecialchars($product['name']); ?></td>
                <td><?= number_format($product['price'], 2); ?></td>
                <td>
                    <a href="edit-product.php?id=<?= $product['id']; ?>">Edit</a> |
                    <a href="delete.php?id=<?= $product['id']; ?>" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</main>

<?php include 'includes/footer.php'; ?>