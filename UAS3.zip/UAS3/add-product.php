<?php
include 'includes/header.php';
include 'includes/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $price = filter_input(INPUT_POST, 'price', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);

    $sql = "INSERT INTO products (name, price) VALUES (:name, :price)";
    $stmt = $conn->prepare($sql);

    if ($stmt->execute(['name' => $name, 'price' => $price])) {
        echo "<p>Produk berhasil ditambahkan.</p>";
    } else {
        echo "<p>Gagal menambahkan produk.</p>";
    }
}
?>

<form method="post" action="add-product.php">
    <h2>Tambah Produk</h2>
    <label>Nama Produk: <input type="text" name="name" required></label><br>
    <label>Harga Produk: <input type="number" name="price" step="0.01" required></label><br>
    <button type="submit">Tambah</button>
</form>

<?php include 'includes/footer.php'; ?>